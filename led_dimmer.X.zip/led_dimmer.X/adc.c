
#include <xc.h>
#include "adc.h"

void init_adc(void) 
{
    ADON = 0; //Diasble the ADC for configuration
    
    /* Select all the channels as ANALOG input */
    PCFG0 = 0; 
    PCFG1 = 0;
    PCFG2 = 0;
    PCFG3 = 0;
    
    VCFG0 = 0;
    VCFG1 = 0; // THE Refrence voltage is kept default
    
    /*Selecting the conversion frequency (freq = 625KHZ, time  = 1.6us)*/
    ADCS0 = 0;
    ADCS1 = 1;
    ADCS2 = 0; 
    
    /*Selecting the Acquistion time  (4TAD = 4*1.6us  = 6.4us)*/
    ACQT0 = 0;
    ACQT1 = 1;
    ACQT2 = 0;
    
    ADFM = 1; // Right Justification
    
    ADON = 1;
    
}

unsigned short read_adc(unsigned char channel)
{
    ADCON0 = (ADCON0 & 0xC3) | (channel << 2);
    
    GO = 1;
    
    while(GO);
    
    return (ADRESH << 8) | ADRESL;
}

