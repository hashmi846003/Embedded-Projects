/*
 * File:   main.c
 * Author: ASUS
 *
 * Created on June 26, 2026, 4:16 AM
 */

#include <xc.h>
#include "adc.h"

volatile unsigned int timer_cycle = 0;
unsigned int period = 100;


void init_timer0(void)
{
    /*Setting 16 bit timer register*/
	T08BIT = 1;

/* Selecting internal clock source */
	T0CS = 0;

/* Enabling timer0*/
	TMR0ON = 1;

/* disabling prescaler*/
	PSA = 1;

	TMR0 = 6;
	/* Clearing timer0 overflow interrupt flag bit */
	TMR0IF = 0;

	/* Enabling timer0 overflow interrupt */
	TMR0IE = 1;
}

void init_config()
{
    
    PEIE = 1;
    
    TRISB = 0x00;
    PORTB = 0X00;
    
    init_adc();
    init_timer0();
    
    GIE = 1;
}
void main(void) 
{
    unsigned int duty_cycle = 0,prev_duty = 255;
    init_config();
    while(1)
    {
        duty_cycle = (read_adc(CHANNEL4))/10.23;
       
        if(duty_cycle != prev_duty)
        {
            prev_duty = duty_cycle;
        }
        
        if(timer_cycle < duty_cycle)
        {
                PORTB = 0xFF;
        }
        else
        {
                PORTB = 0x00;
        }
        
    
    }
}

