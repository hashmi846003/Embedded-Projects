#ifndef ADC_H
#define ADC_H

#define CHANNEL0  0X00
#define CHANNEL1  0X01
#define CHANNEL2  0X02
#define CHANNEL3  0X03
#define CHANNEL4  0X04
#define CHANNEL5  0X05
#define CHANNEL6  0X06
#define CHANNEL7  0X07
#define CHANNEL8  0X08
#define CHANNEL9  0X09
#define CHANNEL10 0X0A


void init_adc(void);
unsigned short read_adc(unsigned char channel);
#endif