
#include <xc.h>

volatile extern unsigned int timer_cycle;
extern unsigned int period;
void __interrupt()isr(void)
{
 
    if(TMR0IF == 1)
    {
       
        TMR0 = TMR0 + 8;
        
        timer_cycle++;
        
        if(timer_cycle >= period)    
            timer_cycle = 0;
        TMR0IF = 0;
    }
}