

#include <xc.h>

extern unsigned int sec;
extern unsigned int count ;
void __interrupt()isr(void)
{
   
    if(TMR0IF == 1)
    {
        TMR0 = TMR0 + 8;
        if(count++ == 5000)
        {
            count = 0;
            sec++;
        }
        TMR0IF = 0;
    }
}
