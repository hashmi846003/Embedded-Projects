
#include <xc.h>
#include "digital_keypad.h"

void init_dkp(void)
{
    TRISC = TRISC | 0x0F;
    PORTC = 0x00;
}

unsigned char read_dkp(unsigned char trigger)
{
    if(trigger == LEVEL)
    {
        return (PORTC & 0x0F);
    }
    else if(trigger == EDGE)
    {
        static unsigned char completed = 1;

        if((PORTC & 0x0F) != 0x0F && completed)
        {
            completed = 0;
            return (PORTC & 0x0F);
        }
        else if((PORTC & 0x0F) == 0x0F)
        {
            completed = 1;
        }

        return 0x0F;
    }
}