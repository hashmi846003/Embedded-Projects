

#include <xc.h>
#include"digital_keypad.h"
#include"ssd_display.h"
unsigned char digit_pattern[] = {ZERO,ONE,TWO,THREE,FOUR,FIVE,SIX,SEVEN,EIGHT,NINE};
unsigned int sec = 0;
unsigned int count = 0;
unsigned char blink = 0;
void init_config(void)
{
    PEIE = 1;
    
    T08BIT = 1;

	T0CS = 0;

	TMR0ON = 1;


	PSA = 0;
    T0PS2 = 0;
    T0PS1 = 0;
    T0PS0 = 1;

	TMR0 = 6;
	
	TMR0IF = 0;
	TMR0IE = 1;
    
    GIE = 1;
    
    init_ssd_control();
    init_dkp();
}
void main(void) 
{
    unsigned char ssd[max_ssd_cnt];
    
    unsigned mode = 0, field = 0;
    unsigned short min = 0;
    unsigned short hour =0;
    init_config();
    
    unsigned char key = 0;
    while(1)
    {
     key = read_dkp(EDGE);

    /* SW4 toggles mode */
    if(key == SW4)
    {
        mode = !mode;
    }

    /* SET MODE */
    if(mode == 0)
    {
        blink = 1;
        if(sec == 60)
        {
            sec = 0;
            min++;
            if(min == 60)
            {
                min = 0;

                hour++;

                if(hour == 24)
                {
                    hour = 0;
                }
            }
        }
    }

    /* EDIT MODE */
    else
    {
        blink = 0;
        if(key == SW3)
        {
            field = !field;
        }

        /* Minute selected */
        if(field == 0)
        {
            if(key == SW1)
            {
                if(min < 59)
                {
                    min++;
                }
              
            }
            else if(key == SW2)
            {
                if(min >0)
                {
                    min--;
                }
            }
        }

        /* Hour selected */
        else
        {
            if(key == SW1)
            {
                if(hour < 23)
                {
                    hour++;
                }
            }

            if(key == SW2)
            {
                if(hour >0)
                {
                    hour--;
                }
            }
        }
      }
     if(mode == 0)
     {
         ssd[3] = digit_pattern[(min %10)];
         ssd[2] = digit_pattern[(min/10)];
         ssd[1] = digit_pattern[(hour %10)];
         ssd[0] = digit_pattern[(hour /10)];
     }
     else
     {
         if(field == 0)
         {
             if(count < 2500)
            {
              ssd[3] = 0;
              ssd[2] = 0;
             
             ssd[1] = digit_pattern[(hour %10)];
             ssd[0] = digit_pattern[(hour /10)];
             
            }
            else if(count < 5000)
            {
                ssd[3] = digit_pattern[(min %10)];
                ssd[2] = digit_pattern[(min /10)];
                
                ssd[1] = digit_pattern[(hour %10)];
                ssd[0] = digit_pattern[(hour /10)];
                
            }
         }
         else if(field == 1)
         {
             if(count < 2500)
            {
              
             ssd[3] = digit_pattern[(min %10)];
             ssd[2] = digit_pattern[(min /10)];
             
             ssd[1] = 0x00;
             ssd[0] = 0x00;
             
            }
            else if(count >2500 && count < 5000)
            {
                ssd[3] = digit_pattern[(min %10)];
                ssd[2] = digit_pattern[(min /10)];
                
                ssd[1] = digit_pattern[(hour %10)];
                ssd[0] = digit_pattern[(hour /10)];
                
            }
         }
     }
      display(ssd);
    }
}