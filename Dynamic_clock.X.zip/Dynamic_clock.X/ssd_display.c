
#include <xc.h>
#include "ssd_display.h"

extern unsigned char blink;
extern unsigned int count;
void init_ssd_control(void)
{
    TRISD = 0x00;
    TRISA = TRISA & 0xF0;
    SSD_CONTROL_PORT = SSD_CONTROL_PORT & 0xF0;
}
void display (unsigned char data[]) 
{
    unsigned char digit;
    for(digit = 0;digit < max_ssd_cnt;digit++)
    {        
         if((blink == 1 )&& count <= 2500)
        {
            data[1] |= 0x10;
        }
        else
        {
            data[1] &= ~0x10;
        }
        SSD_DATA_PORT = data[digit];
		SSD_CONTROL_PORT = (SSD_CONTROL_PORT & 0xF0) | (0x01 << digit);
        
        for(unsigned int wait = 500; wait--; );
        
    }
    
}
