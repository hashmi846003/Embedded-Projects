
#include <xc.h>
#define _XTAL_FREQ 4000000

void main(void) {
    TRISB = 0x00;
    PORTB = 0x00;
    int direction = 0;
    
    while(1) {
        if(direction == 0) {
            for(int i=0; i<8; i++) {
                PORTB |= (1 << i);
                __delay_ms(1000);
            }
            for(int i=0; i<8; i++) {
                PORTB &= ~(1 << i);
                __delay_ms(1000);
            }
        } else {
            for(int i=7; i>=0; i--) {
                PORTB |= (1 << i);
                __delay_ms(1000);
            }
            for(int i=7; i>=0; i--) {
                PORTB &= ~(1 << i);
                __delay_ms(1000);
            }
        }
        direction = !direction;
    }
}
