/*
 * File:   main.c
 * Author: ASUS
 *
 * Created on May 20, 2026, 6:24 PM
 */
#include <xc.h>
#include "keypad.h"
#include "ssd.h"
#define _XTAL_FREQ 20000000 
unsigned int counter = 0;
unsigned char digit_to_ssd(unsigned char digit)
{
    switch(digit)
    {
        case 0: return ZERO;
        case 1: return ONE;
        case 2: return TWO;
        case 3: return THREE;
        case 4: return FOUR;
        case 5: return FIVE;
        case 6: return SIX;
        case 7: return SEVEN;
        case 8: return EIGHT;
        case 9: return NINE;
        default: return BLANK;
    }
}
unsigned char read_digital_keypad(unsigned char detection_type);

void main(void)
{
    unsigned char key;
    unsigned int press_time = 0;
    unsigned char long_press_flag = 0;
    init_digital_keypad();
    init_ssd_control();

    while(1)
    {
        key = read_digital_keypad(LEVEL);

        if(key == SWITCH1)
        {
            press_time++;
            __delay_ms(10);   
        }
       /* else
        {
            if(press_time >= 200)  
            {
                counter = 0;        
            }
            else if(press_time > 0)
            {
                counter++;          
                if(counter > 9999)
                    counter = 0;
            }
            press_time = 0;
        }
*/
 //       else
else
{
    if (press_time >= 20)   // 20 � 10ms = 200ms
    {
        counter = 0;        
        long_press_flag = 1;   // mark long press
    }
    else if (press_time > 0 && !long_press_flag)
    {
        counter++;          
        if(counter > 9999)
            counter = 0;
    }

    press_time = 0;
    long_press_flag = 0;   // clear flag after release
}

        
        unsigned char digits[4];
        digits[0] = counter / 1000;
        digits[1] = (counter / 100) % 10;
        digits[2] = (counter / 10) % 10;
        digits[3] = counter % 10;

        
        unsigned char ssd_data[4];
        ssd_data[0] = (digits[0] == 0 && counter < 1000) ? BLANK : digit_to_ssd(digits[0]);
        ssd_data[1] = (digits[1] == 0 && counter < 100)  ? BLANK : digit_to_ssd(digits[1]);
        ssd_data[2] = (digits[2] == 0 && counter < 10)   ? BLANK : digit_to_ssd(digits[2]);
        ssd_data[3] = digit_to_ssd(digits[3]);

        display(ssd_data);
    }
}
