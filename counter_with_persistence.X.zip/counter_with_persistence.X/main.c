#include <xc.h>
#define _XTAL_FREQ 20000000

#include "ssd.h"
#include "keypad.h"
#include "wprom.h"

static unsigned char ssd[MAX_SSD_CNT];

unsigned char digit_to_ssd(unsigned char digit)
{
    static unsigned char seg[] =
    {
        ZERO, ONE, TWO, THREE, FOUR,
        FIVE, SIX, SEVEN, EIGHT, NINE
    };

    return seg[digit];
}

void update_ssd(unsigned int count)
{
    ssd[0] = digit_to_ssd((count / 1000) % 10);
    ssd[1] = digit_to_ssd((count / 100) % 10);
    ssd[2] = digit_to_ssd((count / 10) % 10);
    ssd[3] = digit_to_ssd(count % 10);
}

void store_count(unsigned int count)
{
    write_internal_eeprom(0x00, (count >> 8) & 0xFF);
    write_internal_eeprom(0x01, count & 0xFF);
}

unsigned int read_count(void)
{
    unsigned int count;

    count = ((unsigned int)read_internal_eeprom(0x00) << 8);
    count |= read_internal_eeprom(0x01);

    return count;
}

void main(void)
{
    unsigned int count;
    unsigned int long_press = 0;
    unsigned char key_level;
    unsigned char key_event;

    init_ssd_control();
    init_digital_keypad();

    count = read_count();

    if(count > 9999)
    {
        count = 0;
    }

    while(1)
    {
        /* For long press detection */
        key_level = read_digital_keypad(LEVEL);

        if(key_level == SWITCH1)
        {
            long_press++;

            /* Adjust if required */
            if(long_press >= 100)
            {
                count = 0;

                /* Wait till key release */
                while(read_digital_keypad(LEVEL) == SWITCH1)
                {
                    update_ssd(count);
                    display(ssd);
                }

                long_press = 0;
            }
        }
        else
        {
            /* Short press */
            if(long_press > 0 && long_press < 100)
            {
                count++;

                if(count > 9999)
                {
                    count = 0;
                }
            }

            long_press = 0;
        }

        /* Detect SW2 */
        key_event = read_digital_keypad(STATE_CHANGE);

        if(key_event == SWITCH2)
        {
            store_count(count);
        }

        update_ssd(count);
        display(ssd);

        __delay_ms(10);
    }
}