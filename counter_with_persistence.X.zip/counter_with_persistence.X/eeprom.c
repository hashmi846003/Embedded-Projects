/*
 * File:   eeprom.c
 * Author: ASUS
 *
 * Created on May 22, 2026, 5:55 PM
 */


#include <xc.h>

void main(void) {
    return;
}
