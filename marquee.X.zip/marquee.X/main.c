#include <xc.h>
#include "SSD.h"

#define _XTAL_FREQ 20000000


unsigned char message[12] = {
    ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE,BLANK ,BLANK
};

void main(void)
{
    unsigned char ssd[MAX_SSD_CNT];
    unsigned char i = 0;

    init_ssd_control();

    while(1)
    {
        
        ssd[0] = message[i % 12];
        ssd[1] = message[(i+1) % 12];
        ssd[2] = message[(i+2) % 12];
        ssd[3] = message[(i+3) % 12];

        
        for(unsigned int repeat=0; repeat<200; repeat++)
        {
            display(ssd);
        }

       
        i = (i+1) % 12;
    }
}
