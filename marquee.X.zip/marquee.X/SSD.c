#include <xc.h>
#include "SSD.h"

void init_ssd_control(void)
{
    TRISD = 0x00;              // PORTD as output (segments)
    TRISA = TRISA & 0xF0;      // Lower 4 bits of PORTA as output (digit enables)

    SSD_CNT_PORT = SSD_CNT_PORT & 0xF0;   // All SSDs off initially
}

void display(unsigned char data[])
{
    unsigned int wait;
    unsigned char digit;

    for (digit = 0; digit < MAX_SSD_CNT; digit++)
    {
        SSD_DATA_PORT = data[digit];
        SSD_CNT_PORT = (SSD_CNT_PORT & 0xF0) | (0x01 << digit);

        for (wait = 1000; wait--; );      // crude refresh delay
    }
}
