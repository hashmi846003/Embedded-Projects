


#include <xc.h>
#include "main.h"
#include "timer.h"

volatile unsigned char Sec1 = 0;
volatile unsigned char Sec2 = 0;
volatile unsigned char Sec3 = 0;

void init_config(void)
{
    PEIE = 1;
    
    TRISB = 0x00;
    PORTB = 0x00;
   
     init_timer0();
     init_timer1();
     init_timer2();
    
    GIE = 1;
}

void main(void) 
{
    init_config();
    
    while(1)
    {
      ;
    }
}
