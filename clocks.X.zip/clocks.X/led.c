#include <xc.h>
#include "led.h"

void init_led(void)
{
    ADCON1 = 0x0F;

    TRISBbits.TRISB0 = 0;
    TRISBbits.TRISB1 = 0;
    TRISBbits.TRISB2 = 0;

    LED_TMR0 = 0;
    LED_TMR1 = 0;
    LED_TMR2 = 0;
}