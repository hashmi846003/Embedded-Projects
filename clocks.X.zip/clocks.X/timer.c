

#include <xc.h>

void init_timer0(void)
{
    /*Setting 16 bit timer register*/
	T08BIT = 1;

/* Selecting internal clock source */
	T0CS = 0;

/* Enabling timer0*/
	TMR0ON = 1;

/* disabling prescaler*/
	PSA = 1;

	TMR0 = 6;
	/* Clearing timer0 overflow interrupt flag bit */
	TMR0IF = 0;

	/* Enabling timer0 overflow interrupt */
	TMR0IE = 1;
}
void init_timer1(void)
{
   
    T1CONbits.RD16 = 1;
    
    TMR1CS = 0;
    
    TMR1ON = 1;
    
    TMR1IF = 0;
    TMR1IE = 1;
    
    TMR1H = 0x0B;
    TMR1L = 0xDC;
    
}
void init_timer2(void)
{
    /* Enabling timer2*/
    TMR2ON = 1;
    
    /*Setting ticks per overflow*/
    PR2 = 249;
    
    /* Clearing timer0 overflow interrupt flag bit */
	TMR2IF = 0;

	/* Enabling timer0 overflow interrupt */
	TMR2IE = 1;
    
}
