#ifndef LED_H
#define LED_H

#include <xc.h>

#define LED_TMR0   LATBbits.LATB0
#define LED_TMR1   LATBbits.LATB1
#define LED_TMR2   LATBbits.LATB2

void init_led(void);

#endif