#ifndef MAIN_H
#define MAIN_H

#define LED1 PORTBbits.RB0
#define LED2 PORTBbits.RB1
#define LED3 PORTBbits.RB3

#endif
