/*
 * File:   MAIN.c
 * Author: Ruchitha
 *
 * Created on 2 June, 2026, 4:00 PM
 */
#include <xc.h>
#include "clcd.h"
#include <string.h>

static void init_config(void)
{
    init_clcd();
}

void main(void)
{
    char msg[] = "HELLO WORLD ";
    char temp[13];
    int i, j, len;

    init_config();

    len = strlen(msg);

    while(1)
    {
        for(i = 0; i < len; i++)
        {
            for(j = 0; j < len; j++)
            {
                temp[j] = msg[(i + j) % len];
            }

            temp[len] = '\0';

            CLEAR_DISP_SCREEN;
            clcd_print(temp, LINE1(0));

            __delay_ms(500);
        }
    }
}