#include <xc.h>
#include "keypad.h"
#define _XTAL_FREQ 4000000

void pattern1(void) {
    static int direction = 0;
    if(direction == 0) {
        for(int i=0; i<8; i++) {
            PORTB |= (1 << i);
            __delay_ms(1000);
        }
        for(int i=0; i<8; i++) {
            PORTB &= ~(1 << i);
            __delay_ms(1000);
        }
    } else {
        for(int i=7; i>=0; i--) {
            PORTB |= (1 << i);
            __delay_ms(1000);
        }
        for(int i=7; i>=0; i--) {
            PORTB &= ~(1 << i);
            __delay_ms(1000);
        }
    }
    direction = !direction;
}

void pattern2(void) {
    for(int i=0; i<8; i++) {
        PORTB |= (1 << i);
        __delay_ms(500);
    }
    for(int i=0; i<8; i++) {
        PORTB &= ~(1 << i);
        __delay_ms(500);
    }
}

void pattern3(void) {
    PORTB = 0x55;
    __delay_ms(500);
    PORTB = 0xAA;
    __delay_ms(500);
}

void pattern4(void) {
    PORTB = 0x0F;
    __delay_ms(500);
    PORTB = 0xF0;
    __delay_ms(500);
}

void main(void) {
    TRISB = 0x00;
    PORTB = 0x00;
    init_digital_keypad();

    unsigned char current_pattern = ALL_RELEASED;

    while(1) {
        unsigned char key = read_digital_keypad(STATE_CHANGE);
        if(key != ALL_RELEASED) {
            current_pattern = key;
        }

        switch(current_pattern) {
            case SWITCH1: pattern1(); 
            case SWITCH2: pattern2(); 
            case SWITCH3: pattern3(); 
            case SWITCH4: pattern4(); 
            default: PORTB = 0x00; 
        }
    }
}
