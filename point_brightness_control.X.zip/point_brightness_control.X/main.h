#ifndef MAIN_H
#define MAIN_H


#define LEVEL 0
#define EDGE 1


#define SW1 0X0E
#define SW2 0X0D
#define SW3 0X0B
#define SW4 0X07
#define ALL_RELEASED  0x0F

void init_dkp(void);
unsigned char read_dkp(unsigned char );

void init_timer0(void);

#endif