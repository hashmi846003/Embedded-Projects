
#include <xc.h>


extern unsigned short timer_cycle;
void __interrupt()isr(void)
{
    unsigned int count;
 
    if(TMR0IF == 1)
    {
        if(count++ == 10000)
        {
            count = 0;
            if(timer_cycle)
             timer_cycle++;
        }
        TMR0 = TMR0 + 8;
        TMR0IF = 0;
    }
}