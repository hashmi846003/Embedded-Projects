/*
 * File:   main.c
 * Author: ASUS
 *
 * Created on June 26, 2026, 4:10 AM
 */



#include <xc.h>
#include "main.h"
unsigned short timer_cycle = 0;

void init_config()
{
    PEIE = 1;
    
    init_timer0();
    init_dkp();
    
    TRISB = 0x00;
    PORTB = 0x00;
    
    GIE =1;
}

void main(void)
{
    init_config();
    unsigned int period = 100,duty_cycle = 0;
    unsigned int count = 0;
    unsigned char key = 0;
    
    while(1)
    {
       
        key = read_dkp(EDGE);
        
        if(key == SW1)
        {
            timer_cycle = 1;
        }
        
        if(timer_cycle == 0)
            duty_cycle = 50;
        
        else if(timer_cycle <= 5)
              duty_cycle = 100;
        
        else
            duty_cycle = 10;
        
        PORTB = (++count <= duty_cycle) ? 0xFF : 0x00;
        
        if(count > period)
            count = 0;
    }
    return;
}
